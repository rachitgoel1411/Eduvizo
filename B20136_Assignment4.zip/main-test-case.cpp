// Purpose: 
// Author: 
// Date of Creation: 20 October 2022
// Bugs: 
// Date of Modification: 26 October 2022

#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

#include "FibonacciHeap.hpp"

int main() {

	FibonacciHeap fibonacciHeap;
	// cout<<"ok";
	Fibonacci_Heap* heap_obj = fibonacciHeap.Make_Fib_Heap();
	// cout<<"ok";
    // Below set of function calls may change depanding upon the test case(s).
	
	
	fibonacciHeap.Fib_Heap_Insert(heap_obj, 26);
	fibonacciHeap.Fib_Heap_Insert(heap_obj, 7);
	fibonacciHeap.Fib_Heap_Insert(heap_obj, 30);
	fibonacciHeap.Fib_Heap_Insert(heap_obj, 39);
	fibonacciHeap.Fib_Heap_Insert(heap_obj, 10);
	fibonacciHeap.Fib_Heap_Display(heap_obj);
	fibonacciHeap.Extract_Min(heap_obj);

	fibonacciHeap.Fib_Heap_Display(heap_obj);

}

/*
 * Expected output:
 * (10(30(39()->)->26()->)->)
 */