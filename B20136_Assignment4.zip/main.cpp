// Purpose: 
// Author: 
// Date of Creation: 20 October 2022
// Bugs: 
// Date of Modification: 26 October 2022

#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

#include "FibonacciHeap.hpp"

int main() {

	FibonacciHeap fibonacciHeap;
	// cout<<"ok";
	Fibonacci_Heap* heap_obj1 = fibonacciHeap.Make_Fib_Heap();
	// cout<<"ok";
    Fibonacci_Heap* heap_obj2 = fibonacciHeap.Make_Fib_Heap();
    // Below set of function calls may change depanding upon the test case(s).
	
	
	fibonacciHeap.Fib_Heap_Insert(heap_obj1, 26);
	fibonacciHeap.Fib_Heap_Insert(heap_obj1, 7);
	fibonacciHeap.Fib_Heap_Insert(heap_obj1, 30);
	fibonacciHeap.Fib_Heap_Insert(heap_obj1, 39);
	fibonacciHeap.Fib_Heap_Insert(heap_obj1, 10);
	fibonacciHeap.Extract_Min(heap_obj1);
	fibonacciHeap.Fib_Heap_Display(heap_obj1);
    cout<<endl;
    fibonacciHeap.Fib_Heap_Insert(heap_obj2, 126);
	fibonacciHeap.Fib_Heap_Insert(heap_obj2, 17);
	fibonacciHeap.Fib_Heap_Insert(heap_obj2, 130);
	fibonacciHeap.Fib_Heap_Insert(heap_obj2, 139);
	fibonacciHeap.Fib_Heap_Insert(heap_obj2, 110);
	fibonacciHeap.Extract_Min(heap_obj2);
	fibonacciHeap.Fib_Heap_Display(heap_obj2);
    cout<<endl;
    Fibonacci_Heap* heap_obj3 = fibonacciHeap.Make_Fib_Heap();
    heap_obj3=fibonacciHeap.Fib_Heap_Union(heap_obj1,heap_obj2);
    fibonacciHeap.Fib_Heap_Display(heap_obj3);

}