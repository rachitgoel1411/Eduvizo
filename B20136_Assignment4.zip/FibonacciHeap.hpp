// Purpose:
// Author:
// Date of Creation: 20 October 2022
// Bugs:
// Date of Modification: 26 October 2022

#ifndef _FIB_HEAP_H
#define _FIB_HEAP_H

#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

#include "seqLinearList.hpp"

class node
{
public:
	int key;	// Value stored in the node.
	int degree; // Number of children.
	node *parent;
	node *child;
	node *left;	 // Left sibling
	node *right; // Right sibling
	char mark;
	char c;
	node()
	{
	}
	~node() {}
};

/**
 * Represents head of the fibonacci heap.
 * It should always point to the node containing minimum value.
 */
class Fibonacci_Heap
{
public:
	int numberOfNodes;
	node *minNode;

	Fibonacci_Heap() {}
	~Fibonacci_Heap() {}
};

class FibonacciHeap
{

public:
	Fibonacci_Heap *obj;

	/**
	 * Constructor
	 */
	FibonacciHeap()
	{
		obj = new Fibonacci_Heap();
		node *newNode;
		newNode = NULL;

		obj->minNode = newNode;
		obj->numberOfNodes = 0;
	}

	/**
	 * Destructor
	 */
	~FibonacciHeap() {}

	/**
	 * Function Make_Fib_Heap.
	 * Returns an instance of Fibonacci_Heap.
	 */
	Fibonacci_Heap *Make_Fib_Heap()
	{
		return obj;
	}

	/**
	 * Function Fib_Heap_Insert.
	 * Inserts a given integer x into Fibonacci_Heap.
	 * Returns object of the Fibonacci_Heap after insertion.
	 */
	Fibonacci_Heap *Fib_Heap_Insert(Fibonacci_Heap *obj, int x)
	{
		// cout<<x;
		// cout<<"ok";
		node *nodex = new node();
		nodex->key = x;
		// cout<<"ok";
		nodex->degree = 0;
		// cout<<"ok";
		nodex->child = NULL;
		// cout<<"ok";
		nodex->parent = NULL;
		// cout<<"ok";
		nodex->left = nodex;
		nodex->right = nodex;
		// cout<<"ok";
		nodex->mark = 'U';
		nodex->c = 'N';
		// cout<<"ok";

		if (obj->minNode != NULL)
		{
			// cout<<"ok";
			node *a = (obj->minNode)->left;
			nodex->left = (obj->minNode)->left;
			(obj->minNode)->left = nodex;
			nodex->right = obj->minNode;
			a->right = nodex;
			// cout<<"ok";
		}
		if (obj->minNode == NULL || x < (obj->minNode)->key)
		{
			obj->minNode = nodex;
		}

		obj->numberOfNodes = obj->numberOfNodes + 1;
		return obj;
	}

	/**
	 * Function Fib_Heap_Union.
	 * Combines two fibonacci heaps with objects obj1 and obj2.
	 * Returns object of the combined Fibonacci_Heap.
	 */
	Fibonacci_Heap *Fib_Heap_Union(Fibonacci_Heap *obj1, Fibonacci_Heap *obj2)
	{
		Fibonacci_Heap *newheap = Make_Fib_Heap();
		newheap->minNode = obj1->minNode;
		newheap->numberOfNodes = obj1->numberOfNodes;
		node *a = obj2->minNode->right;
		node *b = a->right;
		node *c = newheap->minNode->left;
		node *d = c->left;

		newheap->minNode->left = obj2->minNode;
		obj2->minNode->right = newheap->minNode;
		a->right = c;
		a->left = d;
		c->left = a;
		c->right = b;
		b->left = c;
		d->right = a;

		if (newheap->minNode == NULL || (obj2->minNode != NULL && obj2->minNode < newheap->minNode))
		{
			newheap->minNode = obj2->minNode;
		}

		newheap->numberOfNodes = obj1->numberOfNodes + obj2->numberOfNodes;

		return newheap;
	}

	/**
	 * Function Extract_Min.
	 * Deletes node containing minimum value from the Fibonacci_Heap.
	 * Returns this node containing minimun value.
	 */
	node *Extract_Min(Fibonacci_Heap *obj)
	{
		if (obj->minNode == NULL)
		{
			return NULL;
		}
		else
		{
			// cout<<"here"<<endl;
			node *temp = obj->minNode;
			node *ptr = temp;
			node *x = NULL;
			if (temp->child != NULL)
			{
				x = temp->child;
				do
				{
					ptr = x->right;
					(obj->minNode->left)->right = x;
					x->right = obj->minNode;
					x->left = obj->minNode->left;
					obj->minNode->left = x;
					if (x->key < obj->minNode->key)
					{
						obj->minNode = x;
					}
					x->parent = NULL;
					x = ptr;
				} while (ptr != temp->child);
			}
			temp->left->right = temp->right;
			temp->right->left = temp->left;
			obj->minNode = temp->right;
			if (temp == temp->right && temp->child == NULL)
			{
				obj->minNode = NULL;
			}
			else
			{
				obj->minNode = temp->right;
				Consolidate(obj);
			}
			obj->numberOfNodes = obj->numberOfNodes - 1;
			return temp;
		}
	}

	/**
	 * Function Fib_Heap_Display.
	 * Prints the Fibonacci_Heap.
	 */
	void Fib_Heap_Display(Fibonacci_Heap *obj)
	{
		cout << "(";
		display(obj->minNode);
		cout << ")";
	}

	void display(node *curr)
	{
		if (curr == NULL)
			return;
		node *temp = curr;
		do
		{
			cout << temp->key << "(";
			display(temp->child);
			cout << ")->";
			temp = temp->right;
		} while (temp->key != curr->key);

		return;
	}

	/**
	 * Function Fib_Heap_Find.
	 * Finds the value x in the Fibonacci_Heap.
	 * Returns the node containing value x, otherwise null.
	 */
	node *Fib_Heap_Find(Fibonacci_Heap *obj, int x)
	{
		struct node *found = NULL;
		Fibonacci_Heap *temp = obj;
		struct node *found_ptr = NULL;
		temp->minNode->c = 'Y';
		if (temp->minNode->key == x)
		{
			found_ptr = temp->minNode;
			temp->minNode->c = 'N';
			found = found_ptr;
		}
		if (found_ptr == NULL)
		{
			if (temp->minNode->child != NULL)
			{
				temp->minNode = temp->minNode->child;
				temp->minNode = Fib_Heap_Find(temp, x);
			}
			if (temp->minNode->right->c != 'Y')
			{
				temp->minNode = temp->minNode->right;
				temp->minNode = Fib_Heap_Find(temp, x);
			}
		}
		temp->minNode->c = 'N';
		found = found_ptr;
		return temp->minNode;
	}

	/**
	 * Function Consolidate.
	 * Rearranges the Fibonacci_Heap.
	 */

	Fibonacci_Heap *Consolidate(Fibonacci_Heap *obj)
	{
		int temp;
		int temp2 = ceil(log(obj->numberOfNodes) / log(2));
		struct node *arr[temp2 + 1];
		for (int i = 0; i <= temp2; i++)
		{
			arr[i] = NULL;
		}
		node *ptr = obj->minNode;
		node *ptr2;
		node *ptr3;
		node *ptr4 = ptr;
		do
		{
			ptr4 = ptr4->right;
			temp = ptr->degree;
			while (arr[temp] != NULL)
			{
				ptr2 = arr[temp];
				if (ptr->key > ptr2->key)
				{
					ptr3 = ptr;
					ptr = ptr2;
					ptr2 = ptr3;
				}
				if (ptr2 == obj->minNode)
				{
					obj->minNode = ptr;
				}
				Fib_Heap_Link(ptr2, ptr);
				if (ptr->right == ptr)
				{
					obj->minNode = ptr;
				}
				arr[temp] = NULL;
				temp++;
			}
			arr[temp] = ptr;
			ptr = ptr->right;
		} while (ptr != obj->minNode);
		obj->minNode = NULL;
		for (int j = 0; j <= temp2; j++)
		{
			if (arr[j] != NULL)
			{
				arr[j]->left = arr[j];
				arr[j]->right = arr[j];
				if (obj->minNode != NULL)
				{
					obj->minNode->left->right = arr[j];
					arr[j]->right = obj->minNode;
					arr[j]->left = obj->minNode->left;
					obj->minNode->left = arr[j];
					if (arr[j]->key < obj->minNode->key)
					{
						obj->minNode = arr[j];
					}
				}
				else
				{
					obj->minNode = arr[j];
				}
			}
		}
		return obj;
	}

	void Fib_Heap_Link(node *b, node *a)
	{
		b->left->right = b->right;
		b->right->left = b->left;
		if (a->right == a)
		{
			obj->minNode = a;
		}
		b->left = b;
		b->right = b;
		b->parent = a;
		if (a->child == NULL)
			a->child = b;
		b->right = a->child;
		b->left = a->child->left;
		a->child->left->right = b;
		a->child->left = b;
		if (b->key < a->child->key)
		{
			a->child = b;
		}
		a->degree = a->degree + 1;
	}

	/**
	 * Function get_number_of_nodes.
	 * Returns total number of nodes present in the Fibonacci_Heap.
	 */
	int get_number_of_nodes(Fibonacci_Heap *obj)
	{
		return obj->numberOfNodes;
	}
};

#endif